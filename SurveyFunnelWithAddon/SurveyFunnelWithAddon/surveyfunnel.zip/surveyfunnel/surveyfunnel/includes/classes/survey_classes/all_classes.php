<?php
// Include all survey related classes
include_once(dirname(__FILE__) . "/survey_activity_class.php");
include_once(dirname(__FILE__) . "/survey_class.php");
include_once(dirname(__FILE__) . "/survey_export_class.php");
include_once(dirname(__FILE__) . "/survey_manage_class.php");
include_once(dirname(__FILE__) . "/survey_question_manage_class.php");
?>