
<div class="row">
  <div class="col-md-8">
    <div class="portlet box blue-hoki">
      <div class="portlet-title">
        <div class="caption">
          Survey Title
        </div>
      </div>
    </div>
</div>
</div>
