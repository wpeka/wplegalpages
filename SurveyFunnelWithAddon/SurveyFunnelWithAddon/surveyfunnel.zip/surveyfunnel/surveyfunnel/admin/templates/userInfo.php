<!--  // BEGIN Added By Arvind On 25-July-2013  For Add UserInformation   -->
<div id="survey_funnel_userinfo">
	<form id="sf_userinfo_form" onsubmit="return false;">
		<input type="hidden" name="WP_PLUGIN_URL" value="<?php echo WP_PLUGIN_URL_SLLSAFE; ?>">
		 <input type="hidden" name="question_id" id="question_id" value="">
		<input type="hidden" name="question_type" id="question_type" value="3"> 
	                             
	   <input type="hidden" name="add" id="add" value="User Information (Name/Email)">
	      
	 <h3><input type="checkbox" name="question" id="question"> Add User Information (Name/Email) </h3>	
		<br>
		<div id="updateMsg" class="updateMsg"></div>
		
	</form>
</div>

<!-- End -->