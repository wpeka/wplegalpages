
<h3 align="center">Survey Funnel Instructional Videos</h3>

<p>Click the video image below and you'll be taken to the instructional videos and PDFs.</p>

<a href="https://www.youtube.com/watch?v=D6mKNGPocSc&feature=youtu.be" target="_blank"><img src="<?php echo plugins_url( 'images/howtoVideo.png', __FILE__ );?>" border="0" /></a>

<h3> Survey Funnel Support Desk</h3>
<p> <font face="Tahoma"><a href="mailto:support@surveyfunnel.com">Click Here</a>
to create a support ticket.</font></p>
