
<div>
<div class="admin-links">
	<a href="mailto:support@surveyfunnel.com" class="btn btn-circle btn-info email-support green">Email Support</a>
	<!--<a href="http://www.surveyfunnel.com/members/" class="btn btn-circle blue">Members Area</a>  -->
	<a href="https://wpekaclub.gitbooks.io/survey-funnel-documentation/" target="_blank" class="btn btn-circle btn-info green">Documentation</a>
</div>
</div>
